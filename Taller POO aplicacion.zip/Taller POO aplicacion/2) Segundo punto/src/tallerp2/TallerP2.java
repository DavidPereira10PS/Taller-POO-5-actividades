/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tallerp2;

import javax.swing.JOptionPane;

/**
 *
 * @author Personal
 */
public class TallerP2 {

    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) {
        Formato c1= new Formato("Sebastian","20:10","23/02/19",12000,541);
        Formato c2= new Formato("Carlos","14:20","28/03/19",12000,542);
        Formato c3= new Formato("Pedro","16:35","15/08/19",12000,543);
        
        int totc;
        totc=c1.getCost()+c2.getCost()+c3.getCost();
        JOptionPane.showMessageDialog(null,"El total de Costo de los tiquetes es: "+totc);
        
    }
    
}   
