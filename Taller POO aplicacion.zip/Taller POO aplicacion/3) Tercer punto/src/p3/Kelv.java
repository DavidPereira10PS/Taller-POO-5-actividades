/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p3;

import javax.swing.JOptionPane;

/**
 *
 * @author Acer
 */
public class Kelv implements Itemp{
    //se implementa el metodo conversor de la interface ITemperatura
    public void conver() {
        double k, f, c;
        k = Double.parseDouble(JOptionPane.showInputDialog("Digite grados kelvin"));
        c = k - 273.15;
        f = ((9*(k-273.15)) / 5) + 32;
        JOptionPane.showMessageDialog(null, "kelvin: "+k+"\nCelcius: "+c+"\nFahrenheid: "+f);
    }
    
}
