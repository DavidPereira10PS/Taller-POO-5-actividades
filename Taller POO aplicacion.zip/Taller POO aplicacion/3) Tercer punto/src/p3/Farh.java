/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p3;

import javax.swing.JOptionPane;

/**
 *
 * @author Acer
 */
public class Farh implements Itemp{
    //se implementa el metodo conversor de la interface ITemperatura
    public void conver() {
        double k, f, c;
        f = Double.parseDouble(JOptionPane.showInputDialog("Digite grados fahrenheid"));
        c = (5*(f-32))/9;
        k = ((5*(f-32))/9)+273.15;
        JOptionPane.showMessageDialog(null, "Grados Fahrenheid: "+f+"\nGrados Celcius: "+c+"\nGrados kelvin: "+k);
    }
    
}
