/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tallerp4;

import javax.swing.JOptionPane;

/**
 *
 * @author Personal
 */
public class Dinos {
    public String color;
    public String  patas;
    public String cuernos;
    public int alt;
    public int lar;
    public int anch;
    public int tall;
    public int pesC;
    public int pesD;
    public int totcar;
    public void Tallaje(){
        JOptionPane.showMessageDialog(null,"Ninguno");
    }
    public void Totcarros(){
        
        JOptionPane.showMessageDialog(null,"Ninguno");
    }
    
}
